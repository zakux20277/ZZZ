import React, { useState } from 'react';
import { Trophy, RefreshCw, Menu } from 'lucide-react';

interface Question {
  id: number;
  question: string;
  options: string[];
  correctAnswer: string;
}

const questions: Question[] = [
  {
    id: 1,
    question: "What is Morocco's traditional tea called?",
    options: ["Green Tea with Mint", "Black Tea", "Chamomile Tea", "Earl Grey"],
    correctAnswer: "Green Tea with Mint"
  },
  {
    id: 2,
    question: "What is the name of the traditional Moroccan dress?",
    options: ["Kaftan", "Sari", "Kimono", "Hanbok"],
    correctAnswer: "Kaftan"
  },
  {
    id: 3,
    question: "Which city is known as the 'Red City' of Morocco?",
    options: ["Casablanca", "Fez", "Marrakech", "Rabat"],
    correctAnswer: "Marrakech"
  },
  {
    id: 4,
    question: "عاصمة المغرب",
    options: ["Casablanca", "Rabat", "Tangier", "Fez"],
    correctAnswer: "Rabat"
  }
];

function App() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showScore, setShowScore] = useState(false);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleAnswerClick = (answer: string) => {
    if (isAnswered) return;
    
    setSelectedAnswer(answer);
    setIsAnswered(true);
    
    if (answer === questions[currentQuestion].correctAnswer) {
      setScore(score + 1);
    }

    setTimeout(() => {
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
        setIsAnswered(false);
      } else {
        setShowScore(true);
      }
    }, 1000);
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setScore(0);
    setShowScore(false);
    setSelectedAnswer(null);
    setIsAnswered(false);
  };

  const getButtonClass = (option: string) => {
    if (!isAnswered) return "bg-white hover:bg-amber-50 border-amber-200";
    if (option === questions[currentQuestion].correctAnswer) return "bg-green-500 text-white border-green-500";
    if (option === selectedAnswer) return "bg-red-500 text-white border-red-500";
    return "bg-white opacity-50 border-amber-200";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-500 to-amber-800 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl p-8 max-w-xl w-full relative border-2 border-amber-200">
        {/* Menu Button */}
        <div className="absolute top-4 right-4">
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="p-2 hover:bg-amber-50 rounded-full transition-colors"
          >
            <Menu className="w-6 h-6 text-amber-600" />
          </button>
          
          {/* Dropdown Menu */}
          {isMenuOpen && (
            <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2 z-10 border border-amber-200">
              <button
                onClick={() => {
                  resetQuiz();
                  setIsMenuOpen(false);
                }}
                className="w-full text-left px-4 py-2 hover:bg-amber-50 text-amber-800"
              >
                Restart Quiz
              </button>
              <a
                href="https://en.wikipedia.org/wiki/Morocco"
                target="_blank"
                rel="noopener noreferrer"
                className="block px-4 py-2 hover:bg-amber-50 text-amber-800"
                onClick={() => setIsMenuOpen(false)}
              >
                Learn About Morocco
              </a>
            </div>
          )}
        </div>

        {showScore ? (
          <div className="text-center">
            <Trophy className="w-20 h-20 text-amber-500 mx-auto mb-4" />
            <h2 className="text-3xl font-bold mb-4 text-amber-800">Quiz Completed!</h2>
            <p className="text-xl mb-6 text-amber-700">
              You scored {score} out of {questions.length}
            </p>
            <button
              onClick={resetQuiz}
              className="flex items-center justify-center gap-2 bg-amber-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-amber-700 transition-colors mx-auto"
            >
              <RefreshCw className="w-5 h-5" />
              Try Again
            </button>
          </div>
        ) : (
          <>
            <div className="mb-8">
              <div className="flex justify-between items-center mb-4">
                <span className="text-sm font-medium text-amber-600">
                  Question {currentQuestion + 1}/{questions.length}
                </span>
                <span className="text-sm font-medium text-amber-600">
                  Score: {score}
                </span>
              </div>
              <h2 className="text-2xl font-bold text-amber-800 mb-6">
                {questions[currentQuestion].question}
              </h2>
              <div className="space-y-3">
                {questions[currentQuestion].options.map((option, index) => (
                  <button
                    key={index}
                    onClick={() => handleAnswerClick(option)}
                    className={`w-full p-4 text-left rounded-lg border-2 font-medium transition-all duration-300 hover:border-amber-500 ${getButtonClass(
                      option
                    )}`}
                    disabled={isAnswered}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default App;